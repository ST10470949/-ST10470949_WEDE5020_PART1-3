document.addEventListener('DOMContentLoaded', function () {
    const galleryImages = document.querySelectorAll('.image-gallery img');
    const lightbox = document.querySelector('.lightbox');
    const lbImg = lightbox ? lightbox.querySelector('img') : null;
    const lbClose = lightbox ? lightbox.querySelector('.close') : null;

    if (!lightbox || !lbImg) return;

    galleryImages.forEach(img => {
        img.addEventListener('click', (e) => {
            lbImg.src = e.currentTarget.src;
            lbImg.alt = e.currentTarget.alt || '';
            lightbox.classList.add('open');
            lightbox.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden'; // prevent background scroll
        });
    });

    function closeLightbox() {
        lightbox.classList.remove('open');
        lightbox.setAttribute('aria-hidden', 'true');
        lbImg.src = '';
        document.body.style.overflow = '';
    }

    // Close when clicking overlay or close button
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox || e.target.classList.contains('close')) {
            closeLightbox();
        }
    });

    // Close on Esc
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && lightbox.classList.contains('open')) {
            closeLightbox();
        }
    });

    const searchInput = document.getElementById('product-search');
    const productList = document.getElementById('product-list');
    const noResults = document.getElementById('no-results');

    if (!searchInput || !productList) return;

    const items = Array.from(productList.querySelectorAll('li'));

    searchInput.addEventListener('input', function () {
        const q = searchInput.value.trim().toLowerCase();
        let matches = 0;

        items.forEach(li => {
            const text = li.textContent.toLowerCase();
            if (text.includes(q)) {
                li.style.display = '';
                matches++;
            } else {
                li.style.display = 'none';
            }
        });

        if (noResults) {
            noResults.style.display = matches ? 'none' : 'block';
        }
    });

    // Enquiry form: prevent normal submission, show custom feedback
    const enquiryForm = document.getElementById('enquiry-form');
    const enquiryFeedback = document.getElementById('enquiry-feedback');

    if (enquiryForm) {
        enquiryForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Let browser show native messages if invalid
            if (!enquiryForm.checkValidity()) {
                enquiryForm.reportValidity();
                return;
            }

            // Custom confirmation (replace with AJAX if you want to send to server)
            enquiryFeedback.textContent = 'Thank you — your enquiry has been received. We will contact you shortly.';
            enquiryFeedback.classList.remove('error');
            enquiryFeedback.classList.add('success');

            // Optionally reset the form
            enquiryForm.reset();
        });
    }

    // Contact form: use fetch to send to Formspree and show inline feedback
    const contactForm = document.getElementById('contact-form');
    const contactFeedback = document.getElementById('contact-feedback');

    if (contactForm) {
        contactForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            if (!contactForm.checkValidity()) {
                contactForm.reportValidity();
                return;
            }

            contactFeedback.textContent = 'Sending message…';
            contactFeedback.classList.remove('error', 'success');

            try {
                const action = contactForm.action; // ensure you replaced the endpoint
                const formData = new FormData(contactForm);

                const res = await fetch(action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (res.ok) {
                    contactFeedback.textContent = 'Message sent — thank you. We will reply to your email.';
                    contactFeedback.classList.add('success');
                    contactForm.reset();
                } else {
                    const data = await res.json().catch(() => ({}));
                    contactFeedback.textContent = data?.error || 'Sending failed. Please try again later.';
                    contactFeedback.classList.add('error');
                }
            } catch (err) {
                contactFeedback.textContent = 'Network error — please try again.';
                contactFeedback.classList.add('error');
            }
        });
    }
});