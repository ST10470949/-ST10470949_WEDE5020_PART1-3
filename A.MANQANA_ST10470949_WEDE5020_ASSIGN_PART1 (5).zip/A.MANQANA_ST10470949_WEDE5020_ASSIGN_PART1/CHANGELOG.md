# Changelog

All notable changes to the Abongile's Steroids Master website will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-10-17

### Added
- Initial release of Abongile's Steroids Master website
- Responsive HTML pages: index.html, about.html, products.html, enquiry.html, contact.html, gallery.html
- CSS stylesheet with lime green theme, responsive design, and animations
- JavaScript for interactive features:
  - Lightbox gallery with navigation
  - Product search and filtering
  - Form validation and submission handling
- Product catalog with pricing and images
- Contact forms integrated with Formspree
- SEO optimization with sitemap.xml and robots.txt
- Image gallery with lightbox functionality
- Downloadable product catalogue PDF
- Embedded Google Maps for location
- Social media links (Facebook, Instagram)

### Features
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Product Search**: Real-time filtering of products by name or price
- **Lightbox Gallery**: Click images to view larger versions with navigation
- **Form Handling**: Enquiry and contact forms with validation
- **Accessibility**: ARIA labels, keyboard navigation, semantic HTML
- **SEO**: Sitemap and robots.txt for search engine indexing

### Technical Details
- HTML5 semantic markup
- CSS3 with custom properties (CSS variables)
- Vanilla JavaScript (ES6+)
- No external dependencies except Formspree for forms
- Optimized images and responsive media queries

### Known Issues
- Formspree integration requires active endpoint
- Some product prices marked as "R???" (to be updated)
- Catalogue PDF download link points to external file

### Future Enhancements
- Add more product details and specifications
- Implement shopping cart functionality
- Add user authentication for customer accounts
- Integrate payment processing
- Add blog/news section
- Implement analytics tracking

---

## Types of Changes
- `Added` for new features
- `Changed` for changes in existing functionality
- `Deprecated` for soon-to-be removed features
- `Removed` for now removed features
- `Fixed` for any bug fixes
- `Security` in case of vulnerabilities

## Version History
- 1.0.0: Initial release

---

**Note**: This changelog will be updated with future releases and changes to the website.
