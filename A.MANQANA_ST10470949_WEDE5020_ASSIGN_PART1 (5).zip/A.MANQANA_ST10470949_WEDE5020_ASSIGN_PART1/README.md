# Abongile's Steroids Master Website

## Overview

Abongile's Steroids Master is a professional website for a trusted supplier of quality steroid products and expert advice, located in Port Elizabeth, South Africa. The website serves as an online presence for the business, showcasing products, providing contact information, and facilitating customer enquiries.

## Features

- **Responsive Design**: Optimized for desktop, tablet, and mobile devices using CSS media queries and relative units.
- **Product Catalog**: Interactive product listings with search functionality, pricing, and downloadable catalogue.
- **Image Gallery**: Lightbox-enabled gallery with navigation arrows and keyboard controls.
- **Contact Forms**: Enquiry and contact forms integrated with Formspree for message handling.
- **SEO Optimization**: Includes sitemap.xml and robots.txt for search engine indexing.
- **Accessibility**: Proper ARIA labels, semantic HTML, and keyboard navigation support.

## Project Structure

```
A.MANQANA_ST10470949_WEDE5020_ASSIGN_PART1/
├── FILES/                          # HTML pages
│   ├── index.html                  # Home page
│   ├── about.html                  # About the business
│   ├── products.html               # Product catalog
│   ├── enquiry.html                # Enquiry form
│   ├── contact.html                # Contact details and form
│   └── gallery.html                # Product image gallery
├── css/
│   └── style.css                   # Main stylesheet
├── JS/
│   └── scripts.js                  # JavaScript for interactivity
├── IMAGES/                         # Product and site images
├── xml/
│   ├── sitemap.xml                 # SEO sitemap
│   └── robots.txt                  # Search engine directives
├── PROPOSAL/                       # Project proposal documents
├── screenshots/                    # Website screenshots
├── README.md                       # This file
└── CHANGELOG.md                    # Version history
```

## Technologies Used

- **HTML5**: Semantic markup for structure
- **CSS3**: Styling with responsive design, animations, and theming
- **JavaScript (ES6+)**: DOM manipulation, event handling, and form validation
- **Formspree**: Third-party service for form submissions

## Installation and Usage

This is a static website with no server-side dependencies. To run locally:

1. Clone or download the project files.
2. Open `FILES/index.html` in a modern web browser.
3. Navigate through the site using the menu links.

For development:
- Edit HTML files in `FILES/`
- Modify styles in `css/style.css`
- Update scripts in `JS/scripts.js`

## Screenshots

### Desktop View
![Desktop Screenshot](screenshots/screenshot-desktop.png)

### Tablet View
![Tablet Screenshot](screenshots/screenshot-tablet.png)

### Mobile View
![Mobile Screenshot](screenshots/screenshot-mobile.png)

## Contact Information

- **Business Owner**: Abongile Lathitha Manqana
- **Location**: 54 Ngwevana Street, NU9 Motherwell, Port Elizabeth, Eastern Cape, South Africa 6211
- **Phone**: +27 83 771 9808
- **Email**: info@abongilesteroids.co.za
- **Website**: https://www.abongilesteroids.co.za

## License

© 2025 Abongile's Steroids Master. All rights reserved.

## Disclaimer

This website is for informational purposes only. Consult healthcare professionals before using any products. The business complies with local regulations regarding product sales and distribution.
