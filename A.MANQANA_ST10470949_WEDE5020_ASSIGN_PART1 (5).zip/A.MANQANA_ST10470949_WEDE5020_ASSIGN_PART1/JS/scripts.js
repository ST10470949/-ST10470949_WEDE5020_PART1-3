document.addEventListener('DOMContentLoaded', function () {
    // --- NEW: modal show/hide helpers ---
    function showFormSuccess(message) {
        const modal = document.getElementById('form-success-modal');
        if (!modal) return;
        const msg = modal.querySelector('#form-success-message');
        if (msg) msg.textContent = message;
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    function hideFormSuccess() {
        const modal = document.getElementById('form-success-modal');
        if (!modal) return;
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }
    const okBtn = document.getElementById('form-success-ok');
    if (okBtn) okBtn.addEventListener('click', hideFormSuccess);

    // Prevent default submission and show modal (capture phase) for both forms
    ['enquiry-form', 'contact-form'].forEach(formId => {
        const form = document.getElementById(formId);
        if (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                e.stopImmediatePropagation(); // stop other submit handlers (fetch to Formspree)
                showFormSuccess('Your enquiry has been sent successfully we will get back to you shortly');
            }, true); // capture = true so it runs before other listeners
        }
    });

    // --- EXISTING LIGHTBOX / SEARCH / FORM HANDLERS BELOW ---
    const galleryImages = document.querySelectorAll('.image-gallery img');
    const lightbox = document.querySelector('.lightbox');
    const lbImg = lightbox ? lightbox.querySelector('img') : null;
    const lbClose = lightbox ? lightbox.querySelector('.close') : null;
    const lbPrev = lightbox ? lightbox.querySelector('.lightbox-prev') : null;
    const lbNext = lightbox ? lightbox.querySelector('.lightbox-next') : null;

    let currentIndex = 0;
    const images = Array.from(galleryImages);

    function showImage(idx) {
        if (!images[idx]) return;
        lbImg.src = images[idx].src;
        lbImg.alt = images[idx].alt || '';
        currentIndex = idx;
    }

    images.forEach((img, idx) => {
        img.addEventListener('click', () => {
            showImage(idx);
            lightbox.classList.add('open');
            lightbox.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
        });
    });

    function closeLightbox() {
        lightbox.classList.remove('open');
        lightbox.setAttribute('aria-hidden', 'true');
        lbImg.src = '';
        document.body.style.overflow = '';
    }

    if (lbPrev) {
        lbPrev.addEventListener('click', function (e) {
            e.stopPropagation();
            showImage((currentIndex - 1 + images.length) % images.length);
        });
    }
    if (lbNext) {
        lbNext.addEventListener('click', function (e) {
            e.stopPropagation();
            showImage((currentIndex + 1) % images.length);
        });
    }

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!lightbox || !lightbox.classList.contains('open')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') showImage((currentIndex - 1 + images.length) % images.length);
        if (e.key === 'ArrowRight') showImage((currentIndex + 1) % images.length);
    });

    // Close when clicking overlay or close button
    if (lightbox) {
        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox || e.target.classList.contains('close')) {
                closeLightbox();
            }
        });
    }

    // --- PRODUCT SEARCH/FILTER (keeps original behavior) ---
    const searchInput = document.getElementById('product-search');
    const productCards = document.querySelectorAll('#product-cards .product-card');
    const noResults = document.getElementById('no-results');

    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const q = searchInput.value.trim().toLowerCase();
            let cardMatches = 0;

            productCards.forEach(card => {
                const name = (card.getAttribute('data-name') || '').toLowerCase();
                const price = (card.getAttribute('data-price') || '').toLowerCase();
                if (name.includes(q) || price.includes(q)) {
                    card.style.display = '';
                    cardMatches++;
                } else {
                    card.style.display = 'none';
                }
            });

            if (noResults) {
                noResults.style.display = (cardMatches === 0 && q.length > 0) ? 'block' : 'none';
            }
        });
    }

    // --- CONTACT & ENQUIRY FORM HANDLERS (left intact but will not run because capture handler prevented submission) ---
    const enquiryForm = document.getElementById('enquiry-form');
    const enquiryFeedback = document.getElementById('enquiry-feedback');

    if (enquiryForm) {
        enquiryForm.addEventListener('submit', async function (e) {
            // This handler will not run because capturing listener stopped propagation.
            // Kept for completeness.
        });
    }

    const contactForm = document.getElementById('contact-form');
    const contactFeedback = document.getElementById('contact-feedback');

    if (contactForm) {
        contactForm.addEventListener('submit', async function (e) {
            // This handler will not run because capturing listener stopped propagation.
            // Kept for completeness.
        });
    }
});