document.addEventListener('DOMContentLoaded', function () {
    const galleryImages = document.querySelectorAll('.image-gallery img');
    const lightbox = document.querySelector('.lightbox');
    const lbImg = lightbox ? lightbox.querySelector('img') : null;
    const lbClose = lightbox ? lightbox.querySelector('.close') : null;
    const lbPrev = lightbox ? lightbox.querySelector('.lightbox-prev') : null;
    const lbNext = lightbox ? lightbox.querySelector('.lightbox-next') : null;

    let currentIndex = 0;
    const images = Array.from(galleryImages);

    function showImage(idx) {
        if (!images[idx]) return;
        lbImg.src = images[idx].src;
        lbImg.alt = images[idx].alt || '';
        currentIndex = idx;
    }

    images.forEach((img, idx) => {
        img.addEventListener('click', () => {
            showImage(idx);
            lightbox.classList.add('open');
            lightbox.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
        });
    });

    function closeLightbox() {
        lightbox.classList.remove('open');
        lightbox.setAttribute('aria-hidden', 'true');
        lbImg.src = '';
        document.body.style.overflow = '';
    }

    if (lbPrev) {
        lbPrev.addEventListener('click', function (e) {
            e.stopPropagation();
            showImage((currentIndex - 1 + images.length) % images.length);
        });
    }
    if (lbNext) {
        lbNext.addEventListener('click', function (e) {
            e.stopPropagation();
            showImage((currentIndex + 1) % images.length);
        });
    }

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!lightbox.classList.contains('open')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') showImage((currentIndex - 1 + images.length) % images.length);
        if (e.key === 'ArrowRight') showImage((currentIndex + 1) % images.length);
    });

    // Close when clicking overlay or close button
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox || e.target.classList.contains('close')) {
            closeLightbox();
        }
    });

    // Close on Esc
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && lightbox.classList.contains('open')) {
            closeLightbox();
        }
    });

    // --- PRODUCT SEARCH/FILTER ---
    const searchInput = document.getElementById('product-search');
    const productCards = document.querySelectorAll('#product-cards .product-card');
    const noResults = document.getElementById('no-results');

    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const q = searchInput.value.trim().toLowerCase();
            let cardMatches = 0;

            productCards.forEach(card => {
                const name = card.getAttribute('data-name').toLowerCase();
                const price = card.getAttribute('data-price').toLowerCase();
                if (name.includes(q) || price.includes(q)) {
                    card.style.display = '';
                    cardMatches++;
                } else {
                    card.style.display = 'none';
                }
            });

            if (noResults) {
                noResults.style.display = (cardMatches === 0 && q.length > 0) ? 'block' : 'none';
            }
        });
    }

    // --- ENQUIRY FORM ---
    const enquiryForm = document.getElementById('enquiry-form');
    const enquiryFeedback = document.getElementById('enquiry-feedback');

    if (enquiryForm) {
        enquiryForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Let browser show native messages if invalid
            if (!enquiryForm.checkValidity()) {
                enquiryForm.reportValidity();
                return;
            }

            // Custom confirmation (replace with AJAX if you want to send to server)
            enquiryFeedback.textContent = 'Thank you — your enquiry has been received. We will contact you shortly.';
            enquiryFeedback.classList.remove('error');
            enquiryFeedback.classList.add('success');

            // Optionally reset the form
            enquiryForm.reset();
        });
    }

    // --- CONTACT FORM (FORMSPREE) ---
    const contactForm = document.getElementById('contact-form');
    const contactFeedback = document.getElementById('contact-feedback');

    if (contactForm) {
        contactForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            if (!contactForm.checkValidity()) {
                contactForm.reportValidity();
                return;
            }

            contactFeedback.textContent = 'Sending message…';
            contactFeedback.classList.remove('error', 'success');

            try {
                const action = contactForm.action; // ensure you replaced the endpoint
                const formData = new FormData(contactForm);

                const res = await fetch(action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (res.ok) {
                    contactFeedback.textContent = 'Message sent — thank you. We will reply to your email.';
                    contactFeedback.classList.add('success');
                    contactForm.reset();
                } else {
                    const data = await res.json().catch(() => ({}));
                    contactFeedback.textContent = data?.error || 'Sending failed. Please try again later.';
                    contactFeedback.classList.add('error');
                }
            } catch (err) {
                contactFeedback.textContent = 'Network error — please try again.';
                contactFeedback.classList.add('error');
            }
        });
    }
});